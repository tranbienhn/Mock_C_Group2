#include "ParseFat.h"

void main()
{
	FAT_Display("floppy.img");
}