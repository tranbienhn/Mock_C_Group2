#ifndef	_PARSE_FAT_H
#define _PARSE_FAT_H

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

#define BYTE_PER_FAT_ENTRY	2

// Macro fseek
#define SEEK_SET		0		// Beginning of file
#define SEEK_CUR		1		// Current file pointer position
#define SEEK_END		2		// End of file

// Macro Address of useful Boot info
#define ADDRESS_OF_NUM_OF_BYTE_PER_SEC		0x0B
#define ADDRESS_OF_NUM_OF_RESERVED_SEC		0x0E		// ~ number of sectors before FAT
#define ADDRESS_OF_NUM_OF_FAT				0x10
#define ADDRESS_OF_NUM_OF_SEC_PER_FAT		0x16
#define ADDRESS_OF_NUM_OF_ENTRY_OF_ROOT		0x11
#define ADDRESS_OF_NUM_OF_SEC_PER_CLUS		0x0D

// Macro Root entry
#define NAME_LEN		8
#define EXTENSION_LEN	3
#define RESERVED_LEN	10

// Macro Root entry Offset
#define Offset_to_Name			0x00
#define Offset_to_Extension		0x08
#define Offset_to_Attributes	0x0B
#define Offset_to_Reserved		0x0c
#define Offset_to_Time			0x16
#define Offset_to_Date			0x18
#define Offset_to_StartClus		0x1A
#define Offset_to_Size			0x1C

// Macro Attributes
#define Read_Only(Num)			((Num) & 0x01)
#define Hidden(Num)   			(((Num)& 0x02)>>1)
#define System(Num)				(((Num)& 0x04)>>2)
#define Volume_Label(Num)		(((Num)& 0x08)>>3)
#define Subdirectory(Num)		(((Num)& 0x10)>>4)
#define Flag(Num)				(((Num)& 0x20)>>5)
#define Not_Used1(Num)			(((Num)& 0x40)>>6)
#define Not_Used2(Num)			(((Num)& 0x80)>>7)

// Macro Time
#define Hour(Num)  ((Num) >> 11)
#define	Min(Num)   (((Num) & 0x07E0) >>5)
#define Sec(Num)   ((Num) & 0x001F)*2

// Macro Date
#define Year(Num)  (((Num) >> 9) + 1980)
#define	Month(Num) (((Num) & 0x01E0) >> 5)
#define Day(Num)   ((Num) & 0x001F)

// Macro read 2/4 bytes from Buffer
#define Read_2Byte(Buffer,Address)	(Buffer[Address]) | ((Buffer[Address + 1]) << 8)
#define Read_4Byte(Buffer,Address)	(Buffer[Address]) | ((Buffer[Address + 1]) << 8) | ((Buffer[Address + 2]) << 16) | ((Buffer[Address + 3]) << 24)

typedef struct
{
	uint16_t BytePerSec;		// NUM_OF_BYTE_PER_SEC
	uint16_t ReservedSec;		// NUM_OF_RESERVED_SEC
	uint8_t  NumOfFat;			// NUM_OF_FAT
	uint16_t SecPerFat;			// NUM_OF_SEC_PER_FAT
	uint16_t NumOfRootEntry;	// NUM_OF_ENTRY_OF_ROOT
	uint8_t  SecPerClus;		// NUM_OF_SEC_PER_CLUS
} Boot_t;

typedef struct
{
	uint8_t Name[NAME_LEN];
	uint8_t Extension[EXTENSION_LEN];
	uint8_t Attributes;
	uint8_t Reserved[RESERVED_LEN];
	uint16_t Time;
	uint16_t Date;
	uint16_t StartClus;
	uint32_t Size;
} Entry_t;

void FAT_Display(const char * fileName);

#endif	// _PARSE_FAT_H