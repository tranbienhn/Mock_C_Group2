#include "ParseFat.h"

static FILE * filePtr = NULL;
static Boot_t s_Boot;
static Entry_t s_Entry;

void FAT_OpenFile(const char * fileName)
{
	filePtr = fopen(fileName, "rb");
	if(filePtr != NULL)
	{
		fseek(filePtr, 0x0B, SEEK_SET);
		fread(&s_Boot.BytePerSec, 1, 2, filePtr);
	}
	else
	{
		printf("File not found!");
	}
}

void FAT_CloseFile()
{
	fclose(filePtr);
}

// Function to read 1 sector at given address to SecBuff
void Read_Sec(uint32_t Address, uint8_t * SecBuff)
{
	fseek(filePtr, Address, SEEK_SET);
	fread(SecBuff, 1, s_Boot.BytePerSec, filePtr);
}

// Function to read 1 cluster at given address to ClusBuff
void Read_Clus(uint32_t Address, uint8_t * ClusBuff)
{
	fseek(filePtr, Address, SEEK_SET);
	fread(ClusBuff, 1, s_Boot.BytePerSec * s_Boot.SecPerClus, filePtr);
}

// Function to find next cluster
uint32_t Find_NextClus(uint32_t CurrentClus, uint32_t StartFatSec)
{
	uint32_t CurrentFatEntryAddress;
	uint32_t NextClus;
	uint8_t FatEntryBuff[BYTE_PER_FAT_ENTRY];
	
	CurrentFatEntryAddress = StartFatSec * s_Boot.BytePerSec + (CurrentClus + (CurrentClus >> 1));
	
	fseek(filePtr, CurrentFatEntryAddress, SEEK_SET);
	fgets(FatEntryBuff, BYTE_PER_FAT_ENTRY + 1, filePtr);
	
	if((CurrentClus % 2) == 0)
	{
		NextClus = FatEntryBuff[0] | ((FatEntryBuff[1] & 0xF) << 8);
	}
	else
	{
		NextClus = ((FatEntryBuff[0] & 0xF0) >> 4) | (FatEntryBuff[1] << 4);
	}
	
	return NextClus;
}

// Function to enter Action
int ActionMenu()
{
	int Action;
	printf("\n--------------------------\n");
    printf("EXIT PROGRAM : -1\n");
	printf("ENTER YOUR ACTION : ");
	fflush(stdin);
	scanf("%d", &Action);
	printf("\n--------------------------\n");
	return Action;
}

// Function to print header
void Print_Header()
{
	printf("%-3s", "");
	printf("%-8s","Name");
	printf("%-7s","Ext");
	printf("%-10s","Type");
	printf("%-17s","Date modified");
	printf("%-17s","Time modified");
	printf("%-10s\n","Size");
}

// Function to print 1 Entry
void Load_EntryInfo(uint8_t * EntryBuff)		// Load data from EntryBuff to s_Entry
{
	memcpy(s_Entry.Name, EntryBuff, NAME_LEN);
	s_Entry.Name[NAME_LEN] = '\0';
	memcpy(s_Entry.Extension, EntryBuff + Offset_to_Extension, EXTENSION_LEN);
	s_Entry.Extension[EXTENSION_LEN] = '\0';
	s_Entry.Attributes	= EntryBuff[Offset_to_Attributes];
	s_Entry.Time		= Read_2Byte(EntryBuff, Offset_to_Time);
	s_Entry.Date		= Read_2Byte(EntryBuff, Offset_to_Date);
	s_Entry.StartClus	= Read_2Byte(EntryBuff, Offset_to_StartClus);
	s_Entry.Size		= Read_4Byte(EntryBuff, Offset_to_Size);
}

void Print_EntryInfo()
{
	if('.' == s_Entry.Name[0])
	{
		if('.' == s_Entry.Name[1])
		{
			printf("Go Back");
		}
		else
		{
			printf("Reload");
		}
	}
	else
	{
		printf("%-8s", s_Entry.Name);
		
		if(0 == Subdirectory(s_Entry.Attributes))		// This is Folder
		{
			//printf("%-7s", s_Entry.Extension);
			printf("%-14s", "");
			printf("%.2d/%.2d/%.4d       ", Day(s_Entry.Date), Month(s_Entry.Date), Year(s_Entry.Date));
			printf("%.2d:%.2d:%.2d         ", Hour(s_Entry.Time), Min(s_Entry.Time), Sec(s_Entry.Time));
			printf("%-4d bytes", s_Entry.Size);
		}
		else		// This is File
		{
			printf("%-4s", "");
			printf("%-10s", "Folder");
			printf("%.2d/%.2d/%.4d       ", Day(s_Entry.Date), Month(s_Entry.Date), Year(s_Entry.Date));
			printf("%.2d:%.2d:%.2d         ", Hour(s_Entry.Time), Min(s_Entry.Time), Sec(s_Entry.Time));
		}
	}
	printf("\n");
}

// Functions to read Boot Sector
void Read_Boot(uint8_t * BootBuff)
{
	rewind(filePtr);
	fread(BootBuff, 1, s_Boot.BytePerSec, filePtr);
}

void Load_Boot(uint8_t * BootBuff)		// Load data from BootBuff to s_Boot
{
	s_Boot.BytePerSec		= Read_2Byte(BootBuff, ADDRESS_OF_NUM_OF_BYTE_PER_SEC);
	s_Boot.ReservedSec		= Read_2Byte(BootBuff, ADDRESS_OF_NUM_OF_RESERVED_SEC);
	s_Boot.NumOfFat			= BootBuff[ADDRESS_OF_NUM_OF_FAT];
	s_Boot.SecPerFat		= Read_2Byte(BootBuff, ADDRESS_OF_NUM_OF_SEC_PER_FAT);
	s_Boot.NumOfRootEntry	= Read_2Byte(BootBuff, ADDRESS_OF_NUM_OF_ENTRY_OF_ROOT);
	s_Boot.SecPerClus		= BootBuff[ADDRESS_OF_NUM_OF_SEC_PER_CLUS];
}

// Function to read Root Directory
uint8_t Read_Root(uint32_t StartRootSec, uint32_t NumOfRootSec)
{
	uint8_t * SecBuff = (uint8_t *)malloc(s_Boot.BytePerSec);
	uint8_t * EntryBuff = (uint8_t *)malloc(sizeof(Entry_t));
	uint32_t SecCount = 0;
	uint32_t EntryOffset = 0;
	uint8_t FileNum = 0;
	
	system("cls");
	Print_Header();
	
	// Read all sectors of Root
	do
	{
		// Read 1 sector
		Read_Sec((StartRootSec + SecCount) * s_Boot.BytePerSec, SecBuff);

		// Read all entries of this sector
		do
		{
			// Read 1 entry
			memcpy(EntryBuff, SecBuff + EntryOffset, sizeof(Entry_t));
			
			if(EntryBuff[0] != 0x00)		// if not zero entry
			{
				if(EntryBuff[Offset_to_Attributes] != 0x0F)		// if not a long file name entry
				{
					printf("%-3d", FileNum);
					Load_EntryInfo(EntryBuff);
					Print_EntryInfo();
					FileNum++;
				}
				// Increase EntryOffset to read next entry at next loop
				EntryOffset += sizeof(Entry_t);
			}
		} while(EntryBuff[0] != 0x00 && EntryOffset < s_Boot.BytePerSec);		// break when meet zero entry or finish read 1 sector
		// Reset EntryOffset and increase SecCount to read next sector at next loop
		EntryOffset = 0;
		SecCount++;
	} while(EntryBuff[0] != 0x00 && SecCount < NumOfRootSec);		// break when meet zero entry or finish read all root sectors
	free(SecBuff);
	free(EntryBuff);
	return FileNum;
}

// Function to read Folder
uint8_t Read_Folder(uint32_t StartSec, uint32_t StartFatSec, uint32_t StartDataSec)
{
	uint8_t * SecBuff = (uint8_t *)malloc(s_Boot.BytePerSec);
	uint8_t * EntryBuff = (uint8_t *)malloc(sizeof(Entry_t));
	uint32_t SecCount = 0;
	uint32_t EntryOffset = 0;
	uint8_t FileNum = 0;
	uint32_t CurrentClus;
	
	CurrentClus = (StartSec - StartDataSec) / s_Boot.SecPerClus + 2;
	
	system("cls");
	Print_Header();
	
	// Read all clusters of Folder
	while(CurrentClus != 0xFFF)			// break when meet last cluster
	{
		// Read 1 cluster (Read all sectors of this cluster)
		do
		{
			// Read 1 sector
			Read_Sec(StartSec * s_Boot.BytePerSec, SecBuff);
			
			// Read all entries of this sector
			do
			{
				// Read 1 entry
				memcpy(EntryBuff, SecBuff + EntryOffset, sizeof(Entry_t));
				if(EntryBuff[0] != 0x00)		// if not zero entry
				{
					if(EntryBuff[Offset_to_Attributes] != 0x0F)		// if not a long file name entry
					{
						printf("%-3d", FileNum);
						Load_EntryInfo(EntryBuff);
						Print_EntryInfo();
						FileNum++;
					}
					// Increase EntryOffset to read next entry at next loop
					EntryOffset += sizeof(Entry_t);
				}
			} while(EntryBuff[0] != 0x00 && EntryOffset < s_Boot.BytePerSec);		// break when meet zero entry or finish read 1 sector
			// Reset EntryOffset and increase SecCount to read next sector at next loop
			EntryOffset = 0;
			SecCount++;
		} while(EntryBuff[0] != 0x00 && SecCount < s_Boot.SecPerClus);		// break when meet zero entry or finish read 1 cluster
		// Reset SecCount, find next cluster and find StartSec of next cluster
		SecCount = 0;
		CurrentClus = Find_NextClus(CurrentClus, StartFatSec);
		StartSec = StartDataSec + (CurrentClus - 2) * s_Boot.SecPerClus;
	}
	free(SecBuff);
	free(EntryBuff);
	return FileNum;
}

// Function to print File data
void Print_ClusData(uint32_t Address)
{
	uint8_t * ClusBuff = (uint8_t *)malloc(s_Boot.BytePerSec * s_Boot.SecPerClus);
	uint32_t i;
	
	fseek(filePtr, Address, SEEK_SET);
	fread(ClusBuff, 1, s_Boot.BytePerSec * s_Boot.SecPerClus, filePtr);
	
	for(i = 0; i < s_Boot.BytePerSec * s_Boot.SecPerClus; i++)
	{
		if(ClusBuff[i] != 0x00)
		{
			printf("%c", ClusBuff[i]);
		}
	}
}

void Print_FileData(uint32_t CurrentClus,uint32_t StartFatSec, uint32_t StartRootSec, uint32_t NumOfRootSec)
{
	uint32_t CurrentClusAddress;
	uint32_t NextClus;
	
	NextClus = CurrentClus;
	while(NextClus != 0xFFF)
	{
		CurrentClusAddress = (StartRootSec + NumOfRootSec - 2 + NextClus) * s_Boot.BytePerSec;
		Print_ClusData(CurrentClusAddress);
		NextClus = Find_NextClus(NextClus, StartFatSec);
	}
}

// Function to find and read selected entry
void Find_Read_SelectedRootEntry(int Action, uint32_t StartRootSec, uint32_t NumOfRootSec)
{
	uint8_t * SecBuff = (uint8_t *)malloc(s_Boot.BytePerSec);
	uint8_t * EntryBuff = (uint8_t *)malloc(sizeof(Entry_t));
	uint32_t SecCount = 0;
	uint32_t EntryOffset = 0;
	uint8_t check = -1;
	
	// Read all sectors of Root to find EntryOffset of selected entry
	do
	{
		// Read 1 sector
		Read_Sec((StartRootSec + SecCount) * s_Boot.BytePerSec, SecBuff);
		
		// Find selected entry
		while(check != Action && EntryOffset < s_Boot.BytePerSec)		// break when check == Action or finish read 1 sector
		{
			if(SecBuff[Offset_to_Attributes + EntryOffset] != 0x0F)		// if not a long file name entry
			{
				check++;
			}
			// Increase EntryOffset to read next entry at next loop
			EntryOffset += sizeof(Entry_t);
		}
		if(check != Action)		// if finish read 1 sector but check still != Action, reset EntryOffset and increase SecCount to continue read next sector at next loop
		{
			EntryOffset = 0;
			SecCount++;
		}
	} while(check != Action && SecCount < NumOfRootSec);		// break when check == Action or finish read all root sectors
	// Load selected entry
	memcpy(EntryBuff, SecBuff + EntryOffset - sizeof(Entry_t), sizeof(Entry_t));
	Load_EntryInfo(EntryBuff);
	
	free(SecBuff);
	free(EntryBuff);
}

void Find_Read_SelectedFolderEntry(int Action, uint32_t StartSec, uint32_t StartFatSec, uint32_t StartDataSec)
{
	uint8_t * SecBuff = (uint8_t *)malloc(s_Boot.BytePerSec);
	uint8_t * EntryBuff = (uint8_t *)malloc(sizeof(Entry_t));
	uint32_t SecCount = 0;
	uint32_t EntryOffset = 0;
	uint8_t check = -1;
	uint32_t CurrentClus;
	
	CurrentClus = (StartSec - StartDataSec) / s_Boot.SecPerClus + 2;
	
	// Read all clusters of Folder to find EntryOffset of selected entry
	while(CurrentClus != 0xFFF)		// break when meet last cluster
	{
		// Read 1 cluster (Read all sectors of 1 cluster)
		do
		{
			// Read 1 sector
			Read_Sec((StartSec + SecCount) * s_Boot.BytePerSec, SecBuff);
			
			// Read all entries of this sector
			while(check != Action && EntryOffset < s_Boot.BytePerSec)		// break when check == Action or finish read 1 sector
			{
				if(SecBuff[Offset_to_Attributes + EntryOffset] != 0x0F)		// if not a long file name entry
				{
					check++;
				}
				// Increase EntryOffset to read next entry at next loop
				EntryOffset += sizeof(Entry_t);
			}
			if(check != Action)		// if finish read 1 sector but check still != Action, reset EntryOffset and increase SecCount to continue read next sector at next loop
			{
				EntryOffset = 0;
				SecCount++;
			}
		} while(check != Action && SecCount < s_Boot.SecPerClus);		// break when check == Action or finish read all sectors of cluster
		// Reset SecCount, find next cluster and find StartSec of next cluster
		SecCount = 0;
		CurrentClus = Find_NextClus(CurrentClus, StartFatSec);
		StartSec = StartDataSec + (CurrentClus - 2) * s_Boot.SecPerClus;
	}
	// Load selected entry
	memcpy(EntryBuff, SecBuff + EntryOffset - sizeof(Entry_t), sizeof(Entry_t));
	Load_EntryInfo(EntryBuff);
	
	free(SecBuff);
	free(EntryBuff);
}

// Display
void FAT_Display(const char * fileName)
{
	uint32_t StartFatSec;		// Index of first sector of FAT
	uint32_t NumOfFatSec;		// Num of sectors of FAT
	uint32_t StartRootSec;		// Index of first sector of Root
	uint32_t NumOfRootSec;		// Num of sectors of Root
	uint32_t StartDataSec;		// Index of first sector of Data
	
	uint8_t FileNum;
	int Action;
	uint32_t CurrentSec;
	uint32_t ParentSec;
	
	// Open file and read Boot Sector (First sector)
	FAT_OpenFile(fileName);
	uint8_t * BootBuff = (uint8_t *)malloc(s_Boot.BytePerSec);
	Read_Boot(BootBuff);
	Load_Boot(BootBuff);
	free(BootBuff);
	
	// Calculate Index of first sector of FAT, Root and Data
	StartFatSec  = s_Boot.ReservedSec;
	NumOfFatSec	 = s_Boot.NumOfFat * s_Boot.SecPerFat;
	StartRootSec = s_Boot.ReservedSec + NumOfFatSec;
	NumOfRootSec = (sizeof(Entry_t) * s_Boot.NumOfRootEntry) / s_Boot.BytePerSec;
	StartDataSec = StartRootSec + NumOfRootSec;
	
	// Read Root Directory
	FileNum = Read_Root(StartRootSec, NumOfRootSec);
	CurrentSec = StartRootSec;
	
	while(Action != -1)
	{
		// Choose Action
		do
		{
			Action = ActionMenu();
			if(Action < -1 || Action > FileNum)
			{
				printf("Range of action : [-1 ; %d]\nChoose again!", FileNum);
			}
		} while(Action < -1 || Action > FileNum);
		
		if(-1 != Action)
		{
			// Find and read selected entry
			if(CurrentSec == StartRootSec)
			{
				Find_Read_SelectedRootEntry(Action, StartRootSec, NumOfRootSec);
			}
			else
			{
				Find_Read_SelectedFolderEntry(Action, CurrentSec, StartFatSec, StartDataSec);
			}
			
			// Save parent address if user open a File
			if(0 == Subdirectory(s_Entry.Attributes))
			{
				ParentSec = CurrentSec;
			}
			
			CurrentSec = StartDataSec + (s_Entry.StartClus - 2) * s_Boot.SecPerClus;
			
			if(1 == Subdirectory(s_Entry.Attributes))		// If this is Folder, read Folder
			{
				if(0x00 == s_Entry.StartClus)
				{
					CurrentSec = StartRootSec;
					FileNum = Read_Root(StartRootSec, NumOfRootSec);
				}
				else
				{
					FileNum = Read_Folder(CurrentSec, StartFatSec, StartDataSec);
				}
			}
			else		// If this is File, print File data
			{
				Print_FileData(s_Entry.StartClus, StartFatSec, StartRootSec, NumOfRootSec);
				
				printf("\nPress ENTER to close file");
				fflush(stdin);
				getchar();
				printf("\n--------------------------\n");
				
				CurrentSec = ParentSec;
				if(CurrentSec == StartRootSec)
				{
					FileNum = Read_Root(StartRootSec, NumOfRootSec);
				}
				else
				{
					FileNum = Read_Folder(CurrentSec, StartFatSec, StartDataSec);
				}
			}
		}
	}
	FAT_CloseFile();
	printf("End Program!");
}
